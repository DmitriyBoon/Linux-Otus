# vagrant-nfs
vagrant SRV1 CL1 CL2 +nfs
